import main
import pprint
pprint.pprint(main.cli())